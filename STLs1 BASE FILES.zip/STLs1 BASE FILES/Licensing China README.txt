If you wish to print and sell this item $$$ , please contact me for licensing $$$. 

https://discord.com/ Discord (Sillybutts#5905)
https://www.reddit.com/user/SillyTheGamer Reddit (u/SillyTheGamer)

iamsillybutts@gmail.com email

你好！ 我擁有這個設計。 想生產請聯繫我. 
你好！ 我拥有这个设计。 如果你想生产，请联系我.